
var WebSocketServer = require('../../').Server;
var express = require('express');
var path = require('path');
var app = express();
var https = require('https');
var request = require('request');
var mysql = require('mysql');
var session = require('express-session');

var cookieParser = require('cookie-parser');
var MemoryStore = require('memorystore')(session);
var store = new MemoryStore();



var con = mysql.createConnection({
  host: "localhost",
  port: "3306",
  user: "root",
  password: "mobiledev93"

});


//websocket server

var app = express()

app.use(session({ store: store, secret: '123456', key: 'sid',saveUninitialized: true,resave: true }));
app.use(express.static(path.join(__dirname, '/public')));

// app.get('/', (req, res) => res.send('Hello World!'))

// app.listen(3000, () => console.log('Example app listening on port 3000!'))

   //Cron Jobs
// var CronJob = require('cron').CronJob;
// var job = new CronJob('00 45 14 * * 1-7', function() {
//   /*
//    * Runs every weekday (Monday through Friday)
//    * at 11:30:00 AM. 

//    */
//        console.log("CRON job exectuted");

//   }, function () {
//     /* This function is executed when the job stops */
//     console.log("CRON job exectuted");
//   },
//   true, 
//   'Europe/London' 
// );

//end cron jobs
//
const http = require('http');
const url = require('url');
const WebSocket = require('ws');


app.use(function (req, res) {
  res.send({ msg: "hello" });
});
var connections = new Set();

const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

wss.on('connection', function connection(ws, req) {
  const location = url.parse(req.url, true);
  connections.add(ws);
  // You might use location.query.access_token to authenticate or share sessions
  // or req.headers.cookie (see http://stackoverflow.com/a/16395220/151312)
    ws.upgradeReq = req;
  console.log("REQ" + req.headers + "unique id is " + ws._ultron.id);
  cookieParser(ws.upgradeReq, null, function(err) {
        var sessionID = ws.upgradeReq.cookies['sid'];
        store.get(sessionID, function(err, session) {
          if(err) {
          console.log("Error" + err);

          }
          else {
          console.log("Current session is" + session);
            // session
          }
        });
    }); 

  ws.on('message', function incoming(message) {
    console.log('received: %s', message);
    //todo Call Database to get devIds from traffic db
  });

  ws.send(ws._ultron.id,'something');
});

server.listen(8080, function listening() {
  console.log('Listening on %d', server.address().port);
});
// //end web socket methods

// var requestLoop = setInterval(function(){
//   request({
//       url: "https://api.nasa.gov/planetary/apod?api_key=8536dFknqaMWMdrbPKCLVm1CwHKpcbVrE22IwO2x",
//       method: "GET",
//       timeout: 10000,
//       followRedirect: true,
//       maxRedirects: 10
//   },function(error, response, body){
//       if(!error && response.statusCode == 200){
//           console.log('sucess!');
//       }else{
//           console.log('error' + response.statusCode);
//       }
//   });
// }, 3500);


//Todo
//user creates alert saying notifcation when he wants notification when bitcoin hits 12000 sends to here with duuid   





 // /HTTP REQUEST

// https.get('https://api.nasa.gov/planetary/apod?api_key=8536dFknqaMWMdrbPKCLVm1CwHKpcbVrE22IwO2x', (resp) => {
//   let data = '';
 
//   // A chunk of data has been recieved.
//   resp.on('data', (chunk) => {
//     data += chunk;
//   });
 
//   // The whole response has been received. Print out the result.
//   resp.on('end', () => {
//     // console.log(JSON.parse(data).explanation);
//   });
 
// }).on("error", (err) => {
//   console.log("Error: " + err.message);
// });

// / End HTTP REQUEST
