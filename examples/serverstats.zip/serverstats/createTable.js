
var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  port: "3306",
  user: "root",
  password: "mobiledev93"
  //todo create config file to read these values from

});

ccon.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
  var table1Sql = "CREATE TABLE usersEvents (duuid VARCHAR(255), event VARCHAR(255),eventExectuted(TINYINT))";
  con.query(table1Sql, function (err, result) {
    if (err) throw err;
    console.log("Table created");
  });

   var table2Sql = "CREATE TABLE users (id VARCHAR(255), duuid VARCHAR(255),userSessionID VARCHAR(255))";
  con.query(table2Sql, function (err, result) {
    if (err) throw err;
    console.log("Table created");
  });
});